DROP DATABASE IF EXISTS shopdb;
CREATE DATABASE shopdb;
USE shopdb;

CREATE TABLE memberships (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NOT NULL,
  min_spending DECIMAL(10,2) NOT NULL,
  discount_percent DECIMAL(5,2) DEFAULT 0
);

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  phone VARCHAR(20) UNIQUE,
  password VARCHAR(100) NOT NULL,
  role ENUM('customer','admin') DEFAULT 'customer',
  total_spent DECIMAL(10,2) DEFAULT 0,
  membership_id INT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (membership_id) REFERENCES memberships(id)
);

CREATE TABLE categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  parent_id INT DEFAULT NULL,
  FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE CASCADE
);

CREATE TABLE products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL CHECK (price >= 0),
  sale_percent DECIMAL(5,2) DEFAULT 0 CHECK (sale_percent >= 0 AND sale_percent <= 100),
  image_url VARCHAR(512),
  stock INT DEFAULT NULL CHECK (stock >= 0),
  category_id INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(id)
);

CREATE TABLE product_colors (
  id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT NOT NULL,
  color_name VARCHAR(50) NOT NULL,
  color_code VARCHAR(10) DEFAULT NULL,
  image_url VARCHAR(512) NOT NULL,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

CREATE TABLE product_sizes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  color_id INT NOT NULL,
  size ENUM('XS','S','M','L','XL','XXL') NOT NULL,
  stock INT DEFAULT 0 CHECK (stock >= 0),
  extra_price DECIMAL(10,2) DEFAULT 0,
  FOREIGN KEY (color_id) REFERENCES product_colors(id) ON DELETE CASCADE
);

CREATE TABLE sales (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  discount_percent DECIMAL(5,2) NOT NULL CHECK (discount_percent >= 0 AND discount_percent <= 100),
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE product_sales (
  id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT NOT NULL,
  sale_id INT NOT NULL,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE
);

CREATE TABLE vouchers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(50) UNIQUE NOT NULL,
  description TEXT,
  discount_percent DECIMAL(5,2) CHECK (discount_percent >= 0 AND discount_percent <= 100),
  start_date DATE,
  end_date DATE,
  min_order_value DECIMAL(10,2) DEFAULT 0,
  applicable_category_id INT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (applicable_category_id) REFERENCES categories(id)
);

CREATE TABLE orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  voucher_id INT DEFAULT NULL,
  total_price DECIMAL(10,2) DEFAULT 0 CHECK (total_price >= 0),
  address TEXT,
  phone VARCHAR(20),
  status ENUM('Chờ xác nhận','Đã xác nhận','Đang giao hàng','Đã giao hàng','Đã hủy') DEFAULT 'Chờ xác nhận',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (voucher_id) REFERENCES vouchers(id)
);

CREATE TABLE order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  product_id INT NOT NULL,
  color_id INT DEFAULT NULL,
  size_id INT DEFAULT NULL,
  quantity INT NOT NULL CHECK (quantity > 0),
  price DECIMAL(10,2) NOT NULL CHECK (price >= 0),
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id),
  FOREIGN KEY (color_id) REFERENCES product_colors(id),
  FOREIGN KEY (size_id) REFERENCES product_sizes(id)
);

CREATE TABLE banners (
  id INT AUTO_INCREMENT PRIMARY KEY,
  image_url VARCHAR(500) NOT NULL,
  title VARCHAR(255) NOT NULL,
  subtitle VARCHAR(500) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE revenues (
  id INT AUTO_INCREMENT PRIMARY KEY,
  report_date DATE NOT NULL UNIQUE,
  total_sales DECIMAL(15,2) DEFAULT 0,
  total_orders INT DEFAULT 0
);

DELIMITER //
CREATE TRIGGER update_revenue_after_order
AFTER UPDATE ON orders
FOR EACH ROW
BEGIN
  IF NEW.status = 'Đã giao hàng' AND OLD.status != 'Đã giao hàng' THEN
    INSERT INTO revenues (report_date, total_sales, total_orders)
    VALUES (DATE(NEW.created_at), NEW.total_price, 1)
    ON DUPLICATE KEY UPDATE
      total_sales = total_sales + NEW.total_price,
      total_orders = total_orders + 1;
  END IF;
END //
DELIMITER ;

CREATE OR REPLACE VIEW view_revenue_daily AS
SELECT report_date AS date, total_sales, total_orders
FROM revenues
ORDER BY report_date DESC;

CREATE OR REPLACE VIEW view_revenue_weekly AS
SELECT YEAR(report_date) AS year,
       WEEK(report_date, 1) AS week,
       MIN(report_date) AS start_of_week,
       MAX(report_date) AS end_of_week,
       SUM(total_sales) AS total_sales,
       SUM(total_orders) AS total_orders
FROM revenues
GROUP BY YEAR(report_date), WEEK(report_date, 1)
ORDER BY year DESC, week DESC;

CREATE OR REPLACE VIEW view_revenue_monthly AS
SELECT DATE_FORMAT(report_date, '%Y-%m') AS month,
       SUM(total_sales) AS total_sales,
       SUM(total_orders) AS total_orders
FROM revenues
GROUP BY DATE_FORMAT(report_date, '%Y-%m')
ORDER BY month DESC;

CREATE OR REPLACE VIEW view_revenue_yearly AS
SELECT YEAR(report_date) AS year,
       SUM(total_sales) AS total_sales,
       SUM(total_orders) AS total_orders
FROM revenues
GROUP BY YEAR(report_date)
ORDER BY year DESC;

CREATE OR REPLACE VIEW view_best_selling_products AS
SELECT p.id AS product_id,
       p.name AS product_name,
       SUM(oi.quantity) AS total_sold,
       SUM(oi.price * oi.quantity) AS revenue
FROM order_items oi
JOIN products p ON oi.product_id = p.id
JOIN orders o ON oi.order_id = o.id
WHERE o.status = 'Đã giao hàng'
GROUP BY p.id, p.name
ORDER BY total_sold DESC;

CREATE INDEX idx_user_membership ON users(membership_id);
CREATE INDEX idx_product_category ON products(category_id);
CREATE INDEX idx_orders_user ON orders(user_id);
CREATE INDEX idx_order_status ON orders(status);
CREATE INDEX idx_sales_date ON sales(start_date, end_date);

INSERT INTO categories (name, parent_id) VALUES
('Nam', NULL),
('Nữ', NULL),
('Unisex', NULL);

INSERT INTO categories (name, parent_id) VALUES
('Áo', 1), ('Quần', 1),
('Áo', 2), ('Quần', 2), 
('Áo', 3), ('Quần', 3);

INSERT INTO banners (image_url, title, subtitle) VALUES
('/public/images/banner1.png', 'Chào mừng đến Clothing Shop', 'Bộ sưu tập mới nhất đã có mặt – Giảm giá đến 50% hôm nay!'),
('/public/images/banner2.png', 'Phong cách mới mỗi ngày', 'Khám phá các mẫu áo quần hot trend'),
('/public/images/banner3.png', 'Hàng mới về mỗi tuần', 'Cập nhật liên tục – đừng bỏ lỡ xu hướng mới nhất'),
('/public/images/banner4.png', 'Ưu đãi đặc biệt cuối tuần', 'Giảm thêm 20% cho đơn hàng đầu tiên – Mua ngay hôm nay!');

INSERT INTO products (name, description, price, image_url, stock, category_id)
VALUES
('Áo sơ mi', 'Áo sơ mi không cần ủi dáng ôm', 150000, '/public/images/ao-so-mi-nam-white.png', 50, 4),
('Quần chino', 'Quần chino dáng slim fit', 320000, '/public/images/quan-chino-nam-beige.png', 40, 5),
('Áo sơ mi', 'Áo sơ mi vải linen cao cấp', 280000, '/public/images/ao-so-mi-nu-white.png', 30, 6),
('Quần dài gear', 'Quần dài vải mỏng, mềm mại', 450000, '/public/images/quan-dai-gear-nu-beige.png', 25, 7),
('Áo thun tay ngắn', 'Áo thun tay ngắn nhiều màu', 200000, '/public/images/ao-thun-tay-ngan-unisex-gray.png', 60, 8), 
('Quần dài', 'Quần dài thoải mái cho cả nam và nữ', 250000, '/public/images/quan-dai-unisex-beige.png', 40, 9),
('Áo hoodie', 'Áo hoodie nam chất liệu mềm mại, thoải mái', 150000, '/public/images/ao-hoodie-nam-green.png', 50, 4),
('Quần jean', 'Quần jean nam dáng slim fit, co giãn nhẹ', 320000, '/public/images/quan-jean-nam-light-blue.png', 40, 5),
('Áo thun', 'Áo thun cổ tròn nhiều màu', 280000, '/public/images/ao-thun-co-tron-nu-navy.png', 30, 6),
('Quần dệt kim', 'Quần dệt kim vải gân có thể giặt máy', 450000, '/public/images/quan-det-kim-nu-khaki.png', 25, 7),
('Áo thun tay dài', 'Áo thun tay dài nhiều màu', 200000, '/public/images/ao-thun-tay-dai-unisex-blue.png', 60, 8), 
('Quần short', 'Quần short co giãn dáng slim fit', 250000, '/public/images/quan-short-unisex-white.png', 40, 9);

INSERT INTO product_colors (product_id, color_name, color_code, image_url) VALUES
(1, 'Trắng', '#FFFFFF', '/public/images/ao-so-mi-nam-white.png'),
(1, 'Xanh da trời', '#87CEEB', '/public/images/ao-so-mi-nam-blue.png'),
(2, 'Be', '#F5F5DC', '/public/images/quan-chino-nam-beige.png'),
(2, 'Xanh dương', '#0000FF', '/public/images/quan-chino-nam-blue.png'),
(3, 'Trắng', '#FFFFFF', '/public/images/ao-so-mi-nu-white.png'),
(3, 'Xanh lá', '#008000', '/public/images/ao-so-mi-nu-green.png'),
(4, 'Be', '#F5F5DC', '/public/images/quan-dai-gear-nu-beige.png'),
(4, 'Xanh đậm', '#0A3D3B', '/public/images/quan-dai-gear-nu-green.png'),
(5, 'Xám', '#c0c8d3', '/public/images/ao-thun-tay-ngan-unisex-gray.png'),
(5, 'Xám đậm', '#474b4e', '/public/images/ao-thun-tay-ngan-unisex-dark-gray.png'),
(6, 'Xanh lá', '#5a6151', '/public/images/quan-dai-unisex-green.png'),
(6, 'Be', '#cab99f', '/public/images/quan-dai-unisex-beige.png'),
(7, 'Xanh lá', '#6f7c6b', '/public/images/ao-hoodie-nam-green.png'),
(7, 'Đỏ', '#d74d55', '/public/images/ao-hoodie-nam-red.png'),
(8, 'Xanh trắng', '#e5ecf6', '/public/images/quan-jean-nam-light-blue.png'),
(8, 'Xám đậm', '#232227', '/public/images/quan-jean-nam-dark-gray.png'),
(9, 'Xanh da trời', '#dce2f0', '/public/images/ao-thun-co-tron-nu-blue.png'),
(9, 'Xanh navy', '#2b3b5d', '/public/images/ao-thun-co-tron-nu-navy.png'),
(10, 'Be', '#b6a498', '/public/images/quan-det-kim-nu-khaki.png'),
(10, 'Xám', '#515055', '/public/images/quan-det-kim-nu-gray.png'),
(11, 'Xanh đen', '#2c3546', '/public/images/ao-thun-tay-dai-unisex-blue.png'),
(11, 'Xanh lá', '#b3b6af', '/public/images/ao-thun-tay-dai-unisex-green.png'),
(12, 'Trắng', '#f1f0ee', '/public/images/quan-short-unisex-white.png'),
(12, 'Xám', '#646b7d', '/public/images/quan-short-unisex-gray.png');

INSERT INTO product_sizes (color_id, size, stock, extra_price) VALUES
(1, 'S', 10, 0),(1, 'M', 20, 0),(1, 'L', 15, 0),
(2, 'S', 8, 0),(2, 'M', 18, 0),(2, 'L', 12, 0),
(3, 'S', 10, 0),(3, 'M', 15, 0),(3, 'L', 12, 0),
(4, 'S', 5, 0),(4, 'M', 8, 0),(4, 'L', 10, 0),
(5, 'S', 10, 0),(5, 'M', 8, 0),(5, 'L', 5, 0),
(6, 'S', 12, 0),(6, 'M', 10, 0),(6, 'L', 6, 0),
(7, 'S', 7, 0),(7, 'M', 14, 0),(7, 'L', 9, 0),
(8, 'S', 6, 0),(8, 'M', 12, 0),(8, 'L', 8, 0),
(9, 'S', 15, 0), (9, 'M', 20, 0), (9, 'L', 10, 0),  
(10, 'S', 12, 0), (10, 'M', 18, 0), (10, 'L', 10, 0), 
(11, 'S', 10, 0), (11, 'M', 15, 0), (11, 'L', 12, 0), 
(12, 'S', 8, 0), (12, 'M', 12, 0), (12, 'L', 10, 0),
(13, 'S', 10, 0), (13, 'M', 20, 0), (13, 'L', 15, 0),
(14, 'S', 8, 0), (14, 'M', 18, 0), (14, 'L', 12, 0),
(15, 'S', 8, 0), (15, 'M', 15, 0), (15, 'L', 12, 0),
(16, 'S', 6, 0), (16, 'M', 12, 0), (16, 'L', 10, 0),
(17, 'S', 10, 0), (17, 'M', 15, 0), (17, 'L', 10, 0),
(18, 'S', 8, 0), (18, 'M', 14, 0), (18, 'L', 12, 0),
(19, 'S', 7, 0), (19, 'M', 14, 0), (19, 'L', 10, 0),
(20, 'S', 5, 0), (20, 'M', 10, 0), (20, 'L', 8, 0),
(21, 'S', 10, 0), (21, 'M', 15, 0), (21, 'L', 12, 0),
(22, 'S', 8, 0), (22, 'M', 12, 0), (22, 'L', 10, 0),
(23, 'S', 12, 0), (23, 'M', 10, 0), (23, 'L', 8, 0),
(24, 'S', 10, 0), (24, 'M', 14, 0), (24, 'L', 10, 0);