import { useEffect, useState } from "react";
import API from "../api";
import ProductCard from "../components/ProductCard";
import "../pages/Pages.css";

export default function Home() {
  const [products, setProducts] = useState([]);
  const [banners, setBanners] = useState([]);
  const backendUrl = "http://localhost:5000"; 

  useEffect(() => {
    API.get("/products")
      .then((res) => setProducts(res.data))
      .catch((err) => console.error("Lỗi tải sản phẩm:", err));
    API.get("/banners")
      .then((res) => setBanners(res.data))
      .catch((err) => console.error("Lỗi tải banner:", err));
  }, []);

  return (
    <div className="container-fluid mt-4">
      {/* 🖼 Carousel Banner */}
      <div id="heroCarousel" className="carousel slide mb-4" data-bs-ride="carousel">
        <div className="carousel-inner">
          {banners.length > 0 ? (
            banners.map((b, idx) => (
              <div key={b.id} className={`carousel-item ${idx === 0 ? "active" : ""}`}>
                <img
                  src={`${backendUrl}${b.image_url}`} 
                  className="d-block w-100 rounded-3"
                  alt={b.title || `Banner ${idx + 1}`}
                />
                {(b.title || b.subtitle) && (
                  <div className="carousel-caption d-md-block">
                    {b.title && <h1 className="fw-bold">{b.title}</h1>}
                    {b.subtitle && <p>{b.subtitle}</p>}
                  </div>
                )}
              </div>
            ))
          ) : (
            <div className="carousel-item active">
              <img
                src={`${backendUrl}/public/images/placeholder-banner.jpg`} 
                className="d-block w-100 rounded-3"
                alt="Default Banner"
              />
              <div className="carousel-caption d-md-block">
                <h1 className="fw-bold">Chào mừng đến Clothing Shop</h1>
                <p>Bộ sưu tập mới nhất đã có mặt – Giảm giá đến 50% hôm nay!</p>
              </div>
            </div>
          )}
        </div>

        {banners.length > 1 && (
          <>
            <button
              className="carousel-control-prev"
              type="button"
              data-bs-target="#heroCarousel"
              data-bs-slide="prev"
            >
              <span className="carousel-control-prev-icon" aria-hidden="true"></span>
              <span className="visually-hidden">Previous</span>
            </button>
            <button
              className="carousel-control-next"
              type="button"
              data-bs-target="#heroCarousel"
              data-bs-slide="next"
            >
              <span className="carousel-control-next-icon" aria-hidden="true"></span>
              <span className="visually-hidden">Next</span>
            </button>
          </>
        )}
      </div>

      {/* 🛍 Danh sách sản phẩm */}
      <div className="row g-3">
        <h2 className="fw-bold mb-3 text-center">Danh sách sản phẩm</h2>
        {products.map((p) => (
          <div
            key={p.id}
            className="col-6 col-md-3 d-flex justify-content-center"
          >
            <ProductCard product={p} />
          </div>
        ))}
      </div>

      {/* 🧍‍♂️ Về chúng tôi */}
      <section className="my-5">
        <div className="row align-items-center justify-content-center">
          <div className="col-11 col-md-6 mb-3 mb-md-0 text-center">
            <img
              src="https://cdn.shopify.com/s/files/1/0683/8451/files/ABOUT_SERVICE_IMAGE_SMALL_1024x1024.jpg?1888"
              alt="Về chúng tôi"
              className="img-fluid rounded-3 shadow"
            />
          </div>
          <div className="col-11 col-md-5">
            <h2 className="fw-bold mb-3">Về chúng tôi</h2>
            <p>
              Chúng tôi là <strong>Clothing Shop</strong> – nơi mang đến những bộ sưu tập
              thời trang mới nhất, đa dạng phong cách, chất lượng hàng đầu với giá cả hợp lý.
            </p>
            <p>
              Sứ mệnh của chúng tôi là giúp bạn tự tin thể hiện cá tính qua phong cách ăn mặc,
              với dịch vụ tận tâm và trải nghiệm mua sắm hiện đại.
            </p>
          </div>
        </div>
      </section>

      {/* 👕 Lookbook */}
      <section className="my-5">
        <h2 className="fw-bold text-center mb-4">Lookbook</h2>
        <div className="row g-3 justify-content-center">
          <div className="col-11 col-md-3">
            <img
              src="https://www.rails.com/cdn/shop/files/msu24-lookbook-5_1920x.jpg?v=1713387507"
              className="lookbook-img img-fluid rounded-3 shadow"
              alt="Look 1"
            />
          </div>
          <div className="col-11 col-md-3">
            <img
              src="https://www.initialfashion.com/uploads/attachments/cl1x3ldes1httasgxs98428yv-ps-20220225-initial-5914.full.jpg"
              className="lookbook-img img-fluid rounded-3 shadow"
              alt="Look 2"
            />
          </div>
          <div className="col-11 col-md-3">
            <img
              src="https://www.westside.com/cdn/shop/articles/Untitled_design_-_2024-02-16T164143.113.png?v=1708088745&width=533"
              className="lookbook-img img-fluid rounded-3 shadow"
              alt="Look 3"
            />
          </div>
        </div>
      </section>

      {/* 🎁 Chính sách ưu đãi */}
      <section className="my-5 text-center">
        <h2 className="fw-bold mb-4">Chính sách ưu đãi</h2>
        <div className="row g-3 justify-content-center">
          <div className="col-11 col-md-3">
            <div className="card shadow-sm h-100 policy-card">
              <div className="card-body">
                <h5 className="card-title">🎁 Giảm giá</h5>
                <p className="card-text">Giảm 10% cho khách hàng mới</p>
              </div>
            </div>
          </div>
          <div className="col-11 col-md-3">
            <div className="card shadow-sm h-100 policy-card">
              <div className="card-body">
                <h5 className="card-title">🚚 Freeship</h5>
                <p className="card-text">Miễn phí vận chuyển cho đơn từ 500k</p>
              </div>
            </div>
          </div>
          <div className="col-11 col-md-3">
            <div className="card shadow-sm h-100 policy-card">
              <div className="card-body">
                <h5 className="card-title">🔄 Đổi trả</h5>
                <p className="card-text">Đổi trả miễn phí trong 7 ngày</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ⚙️ Footer */}
      <footer className="footer col-md-12 mt-5 py-4 text-center text-white">
        <p className="mb-1">
          📞 Hotline:{" "}
          <a
            href="tel:0123456789"
            className="text-white text-decoration-none"
          >
            0123-456-789
          </a>
        </p>
        <p className="mb-1">
          📧 Email:{" "}
          <a
            href="mailto:support@shopquanao.com"
            className="text-white text-decoration-none"
          >
            support@shopquanao.com
          </a>
        </p>
        <p className="mb-1">
          🏠 Địa chỉ:{" "}
          <a
            href="https://www.google.com/maps/search/?api=1&query=Đường+Nam+Kỳ+Khởi+Nghĩa,+Phường+Hòa+Phú,+Thủ+Dầu+Một,+Bình+Dương,+Việt+Nam"
            className="text-white text-decoration-none"
            target="_blank"
            rel="noopener noreferrer"
          >
            Đường Nam Kỳ Khởi Nghĩa, Phường Hòa Phú, TP. Thủ Dầu Một, Bình Dương
          </a>
        </p>
        <p className="mb-0">
          © {new Date().getFullYear()} Clothing Shop - All Rights Reserved
        </p>
      </footer>
    </div>
  );
}
